package com.livemusicworld.app;

// Splash Activity placeholder